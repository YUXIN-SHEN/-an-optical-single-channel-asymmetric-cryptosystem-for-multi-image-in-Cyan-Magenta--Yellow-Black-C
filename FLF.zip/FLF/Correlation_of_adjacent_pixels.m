function Caa=Correlation_of_adjacent_pixels(image,choose,n)
%��ȡn����������
%choose ѡ��1ˮƽ��2��ֱ��3�Խ�
%n ��������
image=double(image);
[M,N]=size(image);

x_coor(1,:)=randi([1  N],1,n);%x����x����
x_coor(2,:)=randi([1  M],1,n);%x����y����
y_coor=ones(2,n);%y��������

%%
if choose==1
    %ˮƽ
    for i=1:n
        if x_coor(1,i)==N
            y_coor(1,i)=1;
        end
        if x_coor(1,i)<N
            y_coor(1,i)=x_coor(1,i)+1;
        end
        y_coor(2,i)=x_coor(2,i);
    end
end

%%
if choose==2
    %��ֱ
    for i=1:n
        if x_coor(2,i)==M
            y_coor(2,i)=1;
        end
        if x_coor(2,i)<M
            y_coor(2,i)=x_coor(2,i)+1;
        end
        y_coor(1,i)=x_coor(1,i);
    end
end

%%
if choose==3
    %�Խ�
    for i=1:n
        if x_coor(1,i)==N
            y_coor(1,i)=1;
        end
        if x_coor(1,i)<N
            y_coor(1,i)=x_coor(1,i)+1;
        end
        
        if x_coor(2,i)==M
            y_coor(2,i)=1;
        end
        if x_coor(2,i)<M
            y_coor(2,i)=x_coor(2,i)+1;
        end
    end
end
%%
x=ones(1,n);
y=ones(1,n);
%��ȡ����ֵ
for i=1:n
    x(i)=image(x_coor(2,i),x_coor(1,i));
    y(i)=image(y_coor(2,i),y_coor(1,i));
end

Caa=coefficient_of_association(x,y);



