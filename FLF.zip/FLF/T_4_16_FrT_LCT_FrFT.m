close all
clear all
clc
path(path,'toolbox');

n1=256;
M=n1;N=n1;
z1=0.8;
lambda=0.6328*1e-6; 

hx=2.1095*1e-2;hy=2.1095*1e-2;
dhx=hx/M;dhy=hy/N;
dx0=lambda*z1/(M*dhx);
dy0=lambda*z1/(N*dhy);

%%
%LCT����
aa=2;
bb=1;
dd=7;
%%

%%
%FrFT����
ax=1.25;
ay=1.1;
%%


im = {};
dis = dir('qr16\*.tiff');
% N=length(dis);
for i = 1:16
path = strcat('qr16\',dis(i).name);
im{i} =im2double(imread(path)); %%
% im{i} =rescale(load_image(path,n1));
% figure,imshow(im{i}) %%

end
f1cmyk=rescale(im{1});
f2cmyk=rescale(im{2});
f3cmyk=rescale(im{3});
f4cmyk=rescale(im{4});
f5cmyk=rescale(im{5});
f6cmyk=rescale(im{6});
f7cmyk=rescale(im{7});
f8cmyk=rescale(im{8});
f9cmyk=rescale(im{9});
f10cmyk=rescale(im{10});
f11cmyk=rescale(im{11});
f12cmyk=rescale(im{12});
f13cmyk=rescale(im{13});
f14cmyk=rescale(im{14});
f15cmyk=rescale(im{15});
f16cmyk=rescale(im{16});

% f1cmyk=rescale(load_image('ff500',n1));
% f2cmyk=rescale(load_image('ff550',n1));
% f3cmyk=rescale(load_image('ff600',n1));
% f4cmyk=rescale(load_image('ff650',n1));
% f5cmyk=rescale(load_image('ff500',n1));
% f6cmyk=rescale(load_image('ff550',n1));
% f7cmyk=rescale(load_image('ff600',n1));
% f8cmyk=rescale(load_image('ff650',n1));
% f9cmyk=rescale(load_image('ff500',n1));
% f10cmyk=rescale(load_image('ff550',n1));
% f11cmyk=rescale(load_image('ff600',n1));
% f12cmyk=rescale(load_image('ff650',n1));
% f13cmyk=rescale(load_image('ff500',n1));
% f14cmyk=rescale(load_image('ff550',n1));
% f15cmyk=rescale(load_image('ff600',n1));
% f16cmyk=rescale(load_image('ff650',n1));

% f1cmyk=rescale(load_image('qr500',n1));
% f2cmyk=rescale(load_image('qr550',n1));
% f3cmyk=rescale(load_image('qr600',n1));
% f4cmyk=rescale(load_image('qr650',n1));
% f5cmyk=rescale(load_image('qr500',n1));
% f6cmyk=rescale(load_image('qr550',n1));
% f7cmyk=rescale(load_image('qr600',n1));
% f8cmyk=rescale(load_image('qr650',n1));
% f9cmyk=rescale(load_image('qr500',n1));
% f10cmyk=rescale(load_image('qr550',n1));
% f11cmyk=rescale(load_image('qr600',n1));
% f12cmyk=rescale(load_image('qr650',n1));
% f13cmyk=rescale(load_image('qr500',n1));
% f14cmyk=rescale(load_image('qr550',n1));
% f15cmyk=rescale(load_image('qr600',n1));
% f16cmyk=rescale(load_image('qr650',n1));

f1=cmyk2rgb(f1cmyk);
% figure,imshow(f1);title('f1')

f2=cmyk2rgb(f2cmyk);
% figure,imshow(f2);title('f2')

f3=cmyk2rgb(f3cmyk);
% figure,imshow(f3);title('f3')

f4=cmyk2rgb(f4cmyk);
% figure,imshow(f4);title('f4')

f5=cmyk2rgb(f5cmyk);
% figure,imshow(f5);title('f5')

f6=cmyk2rgb(f6cmyk);
% figure,imshow(f6);title('f6')

f7=cmyk2rgb(f7cmyk);
% figure,imshow(f7);title('f7')

f8=cmyk2rgb(f8cmyk);
% figure,imshow(f8);title('f8')

f9=cmyk2rgb(f9cmyk);
% figure,imshow(f9);title('f9')

f10=cmyk2rgb(f10cmyk);
% figure,imshow(f10);title('f10')

f11=cmyk2rgb(f11cmyk);
% figure,imshow(f11);title('f11')

f12=cmyk2rgb(f12cmyk);
% figure,imshow(f12);title('f12')

f13=cmyk2rgb(f13cmyk);
% figure,imshow(f13);title('f13')

f14=cmyk2rgb(f14cmyk);
% figure,imshow(f14);title('f14')

f15=cmyk2rgb(f15cmyk);
% figure,imshow(f15);title('f15')

f16=cmyk2rgb(f16cmyk);
% figure,imshow(f16);title('f16')


f1c=f1cmyk(:,:,1);
% figure,imshow(f1c);title('f1c')
f1m=f1cmyk(:,:,2);
% figure,imshow(f1m);title('f1m')
f1y=f1cmyk(:,:,3);
% figure,imshow(f1y);title('fy')
f1k=f1cmyk(:,:,4);
% figure,imshow(f1k);title('f1k')

% zero=zeros(256,256);
% f1cc=cat(3,f1c,zero,zero,zero);
% imwrite(f1cc,'f1c.tiff');
% f1mm=cat(3,zero,f1m,zero,zero);
% imwrite(f1mm,'f1m.tiff');
% f1yy=cat(3,zero,zero,f1y,zero);
% imwrite(f1yy,'f1y.tiff');
% f1kk=cat(3,zero,zero,zero,f1k);
% imwrite(f1kk,'f1k.tiff');

f2c=f2cmyk(:,:,1);
% figure,imshow(f1c);title('f1c')
f2m=f2cmyk(:,:,2);
% figure,imshow(f1m);title('f1m')
f2y=f2cmyk(:,:,3);
% figure,imshow(f1y);title('fy')
f2k=f2cmyk(:,:,4);
% figure,imshow(f1k);title('f1k')

% f2cc=cat(3,f2c,zero,zero,zero);
% imwrite(f2cc,'f2c.tiff');
% f2mm=cat(3,zero,f2m,zero,zero);
% imwrite(f2mm,'f2m.tiff');
% f2yy=cat(3,zero,zero,f2y,zero);
% imwrite(f2yy,'f2y.tiff');
% f2kk=cat(3,zero,zero,zero,f2k);
% imwrite(f2kk,'f2k.tiff');

f3c=f3cmyk(:,:,1);
% figure,imshow(f1c);title('f1c')
f3m=f3cmyk(:,:,2);
% figure,imshow(f1m);title('f1m')
f3y=f3cmyk(:,:,3);
% figure,imshow(f1y);title('fy')
f3k=f3cmyk(:,:,4);
% figure,imshow(f1k);title('f1k')

% f3cc=cat(3,f3c,zero,zero,zero);
% imwrite(f3cc,'f3c.tiff');
% f3mm=cat(3,zero,f3m,zero,zero);
% imwrite(f3mm,'f3m.tiff');
% f3yy=cat(3,zero,zero,f3y,zero);
% imwrite(f3yy,'f3y.tiff');
% f3kk=cat(3,zero,zero,zero,f3k);
% imwrite(f3kk,'f3k.tiff');

f4c=f4cmyk(:,:,1);
% figure,imshow(f1c);title('f1c')
f4m=f4cmyk(:,:,2);
% figure,imshow(f1m);title('f1m')
f4y=f4cmyk(:,:,3);
% figure,imshow(f1y);title('fy')
f4k=f4cmyk(:,:,4);
% figure,imshow(f1k);title('f1k')

f5c=f5cmyk(:,:,1);
% figure,imshow(f1c);title('f1c')
f5m=f5cmyk(:,:,2);
% figure,imshow(f1m);title('f1m')
f5y=f5cmyk(:,:,3);
% figure,imshow(f1y);title('fy')
f5k=f5cmyk(:,:,4);
% figure,imshow(f1k);title('f1k')

f6c=f6cmyk(:,:,1);
% figure,imshow(f1c);title('f1c')
f6m=f6cmyk(:,:,2);
% figure,imshow(f1m);title('f1m')
f6y=f6cmyk(:,:,3);
% figure,imshow(f1y);title('fy')
f6k=f6cmyk(:,:,4);
% figure,imshow(f1k);title('f1k')

f7c=f7cmyk(:,:,1);
% figure,imshow(f1c);title('f1c')
f7m=f7cmyk(:,:,2);
% figure,imshow(f1m);title('f1m')
f7y=f7cmyk(:,:,3);
% figure,imshow(f1y);title('fy')
f7k=f7cmyk(:,:,4);
% figure,imshow(f1k);title('f1k')

f8c=f8cmyk(:,:,1);
% figure,imshow(f1c);title('f1c')
f8m=f8cmyk(:,:,2);
% figure,imshow(f1m);title('f1m')
f8y=f8cmyk(:,:,3);
% figure,imshow(f1y);title('fy')
f8k=f8cmyk(:,:,4);
% figure,imshow(f1k);title('f1k')

f9c=f9cmyk(:,:,1);
% figure,imshow(f1c);title('f1c')
f9m=f9cmyk(:,:,2);
% figure,imshow(f1m);title('f1m')
f9y=f9cmyk(:,:,3);
% figure,imshow(f1y);title('fy')
f9k=f9cmyk(:,:,4);
% figure,imshow(f1k);title('f1k')

f10c=f10cmyk(:,:,1);
% figure,imshow(f1c);title('f1c')
f10m=f10cmyk(:,:,2);
% figure,imshow(f1m);title('f1m')
f10y=f10cmyk(:,:,3);
% figure,imshow(f1y);title('fy')
f10k=f10cmyk(:,:,4);
% figure,imshow(f1k);title('f1k')

f11c=f11cmyk(:,:,1);
% figure,imshow(f1c);title('f1c')
f11m=f11cmyk(:,:,2);
% figure,imshow(f1m);title('f1m')
f11y=f11cmyk(:,:,3);
% figure,imshow(f1y);title('fy')
f11k=f11cmyk(:,:,4);
% figure,imshow(f1k);title('f1k')

f12c=f12cmyk(:,:,1);
% figure,imshow(f1c);title('f1c')
f12m=f12cmyk(:,:,2);
% figure,imshow(f1m);title('f1m')
f12y=f12cmyk(:,:,3);
% figure,imshow(f1y);title('fy')
f12k=f12cmyk(:,:,4);
% figure,imshow(f1k);title('f1k')

f13c=f13cmyk(:,:,1);
% figure,imshow(f1c);title('f1c')
f13m=f13cmyk(:,:,2);
% figure,imshow(f1m);title('f1m')
f13y=f13cmyk(:,:,3);
% figure,imshow(f1y);title('fy')
f13k=f13cmyk(:,:,4);
% figure,imshow(f1k);title('f1k')

f14c=f14cmyk(:,:,1);
% figure,imshow(f1c);title('f1c')
f14m=f14cmyk(:,:,2);
% figure,imshow(f1m);title('f1m')
f14y=f14cmyk(:,:,3);
% figure,imshow(f1y);title('fy')
f14k=f14cmyk(:,:,4);
% figure,imshow(f1k);title('f1k')

f15c=f15cmyk(:,:,1);
% figure,imshow(f1c);title('f1c')
f15m=f15cmyk(:,:,2);
% figure,imshow(f1m);title('f1m')
f15y=f15cmyk(:,:,3);
% figure,imshow(f1y);title('fy')
f15k=f15cmyk(:,:,4);
% figure,imshow(f1k);title('f1k')

f16c=f16cmyk(:,:,1);
% figure,imshow(f1c);title('f1c')
f16m=f16cmyk(:,:,2);
% figure,imshow(f1m);title('f1m')
f16y=f16cmyk(:,:,3);
% figure,imshow(f1y);title('fy')
f16k=f16cmyk(:,:,4);
% figure,imshow(f1k);title('f1k')


% f4cc=cat(3,f4c,zero,zero,zero);
% imwrite(f4cc,'f4c.tiff');
% f4mm=cat(3,zero,f4m,zero,zero);
% imwrite(f4mm,'f4m.tiff');
% f4yy=cat(3,zero,zero,f4y,zero);
% imwrite(f4yy,'f4y.tiff');
% f4kk=cat(3,zero,zero,zero,f4k);
% imwrite(f4kk,'f4k.tiff');

RPM1=exp(1i*2*pi*rand(M,N));
RPM2=exp(1i*2*pi*rand(M,N));
RPM3=exp(1i*2*pi*rand(M,N));
RAM1=1;
RAM2=1;
RAM3=1;

%%% ENCRYPTION PROCESS
tic

%%%��һ��%%%
[Ccmyk1,p331,p221,p111]=encrypt_FrT_LCT_FrFT(f1c,f1m,f1y,f1k,RAM1,RPM1,RAM2,RPM2,RAM3,RPM3,M,N,dx0,dy0,z1,lambda,aa,bb,dd,ax,ay);
[Ccmyk2,p332,p222,p112]=encrypt_FrT_LCT_FrFT(f2c,f2m,f2y,f2k,RAM1,RPM1,RAM2,RPM2,RAM3,RPM3,M,N,dx0,dy0,z1,lambda,aa,bb,dd,ax,ay);
[Ccmyk3,p333,p223,p113]=encrypt_FrT_LCT_FrFT(f3c,f3m,f3y,f3k,RAM1,RPM1,RAM2,RPM2,RAM3,RPM3,M,N,dx0,dy0,z1,lambda,aa,bb,dd,ax,ay);
[Ccmyk4,p334,p224,p114]=encrypt_FrT_LCT_FrFT(f4c,f4m,f4y,f4k,RAM1,RPM1,RAM2,RPM2,RAM3,RPM3,M,N,dx0,dy0,z1,lambda,aa,bb,dd,ax,ay);
[Ccmyk5,p335,p225,p115]=encrypt_FrT_LCT_FrFT(f5c,f5m,f5y,f5k,RAM1,RPM1,RAM2,RPM2,RAM3,RPM3,M,N,dx0,dy0,z1,lambda,aa,bb,dd,ax,ay);
[Ccmyk6,p336,p226,p116]=encrypt_FrT_LCT_FrFT(f6c,f6m,f6y,f6k,RAM1,RPM1,RAM2,RPM2,RAM3,RPM3,M,N,dx0,dy0,z1,lambda,aa,bb,dd,ax,ay);
[Ccmyk7,p337,p227,p117]=encrypt_FrT_LCT_FrFT(f7c,f7m,f7y,f7k,RAM1,RPM1,RAM2,RPM2,RAM3,RPM3,M,N,dx0,dy0,z1,lambda,aa,bb,dd,ax,ay);
[Ccmyk8,p338,p228,p118]=encrypt_FrT_LCT_FrFT(f8c,f8m,f8y,f8k,RAM1,RPM1,RAM2,RPM2,RAM3,RPM3,M,N,dx0,dy0,z1,lambda,aa,bb,dd,ax,ay);
[Ccmyk9,p339,p229,p119]=encrypt_FrT_LCT_FrFT(f9c,f9m,f9y,f9k,RAM1,RPM1,RAM2,RPM2,RAM3,RPM3,M,N,dx0,dy0,z1,lambda,aa,bb,dd,ax,ay);
[Ccmyk10,p3310,p2210,p1110]=encrypt_FrT_LCT_FrFT(f10c,f10m,f10y,f10k,RAM1,RPM1,RAM2,RPM2,RAM3,RPM3,M,N,dx0,dy0,z1,lambda,aa,bb,dd,ax,ay);
[Ccmyk11,p3311,p2211,p1111]=encrypt_FrT_LCT_FrFT(f11c,f11m,f11y,f11k,RAM1,RPM1,RAM2,RPM2,RAM3,RPM3,M,N,dx0,dy0,z1,lambda,aa,bb,dd,ax,ay);
[Ccmyk12,p3312,p2212,p1112]=encrypt_FrT_LCT_FrFT(f12c,f12m,f12y,f12k,RAM1,RPM1,RAM2,RPM2,RAM3,RPM3,M,N,dx0,dy0,z1,lambda,aa,bb,dd,ax,ay);
[Ccmyk13,p3313,p2213,p1113]=encrypt_FrT_LCT_FrFT(f13c,f13m,f13y,f13k,RAM1,RPM1,RAM2,RPM2,RAM3,RPM3,M,N,dx0,dy0,z1,lambda,aa,bb,dd,ax,ay);
[Ccmyk14,p3314,p2214,p1114]=encrypt_FrT_LCT_FrFT(f14c,f14m,f14y,f14k,RAM1,RPM1,RAM2,RPM2,RAM3,RPM3,M,N,dx0,dy0,z1,lambda,aa,bb,dd,ax,ay);
[Ccmyk15,p3315,p2215,p1115]=encrypt_FrT_LCT_FrFT(f15c,f15m,f15y,f15k,RAM1,RPM1,RAM2,RPM2,RAM3,RPM3,M,N,dx0,dy0,z1,lambda,aa,bb,dd,ax,ay);
[Ccmyk16,p3316,p2216,p1116]=encrypt_FrT_LCT_FrFT(f16c,f16m,f16y,f16k,RAM1,RPM1,RAM2,RPM2,RAM3,RPM3,M,N,dx0,dy0,z1,lambda,aa,bb,dd,ax,ay);

[Ccmykn1,pn331,pn221,pn111]=encrypt_FrT_LCT_FrFT(Ccmyk1,Ccmyk2,Ccmyk3,Ccmyk4,RAM1,RPM1,RAM2,RPM2,RAM3,RPM3,M,N,dx0,dy0,z1,lambda,aa,bb,dd,ax,ay);
[Ccmykn2,pn332,pn222,pn112]=encrypt_FrT_LCT_FrFT(Ccmyk5,Ccmyk6,Ccmyk7,Ccmyk8,RAM1,RPM1,RAM2,RPM2,RAM3,RPM3,M,N,dx0,dy0,z1,lambda,aa,bb,dd,ax,ay);
[Ccmykn3,pn333,pn223,pn113]=encrypt_FrT_LCT_FrFT(Ccmyk9,Ccmyk10,Ccmyk11,Ccmyk12,RAM1,RPM1,RAM2,RPM2,RAM3,RPM3,M,N,dx0,dy0,z1,lambda,aa,bb,dd,ax,ay);
[Ccmykn4,pn334,pn224,pn114]=encrypt_FrT_LCT_FrFT(Ccmyk13,Ccmyk14,Ccmyk15,Ccmyk16,RAM1,RPM1,RAM2,RPM2,RAM3,RPM3,M,N,dx0,dy0,z1,lambda,aa,bb,dd,ax,ay);

[Ccmyk,p33,p22,p11]=encrypt_FrT_LCT_FrFT(Ccmykn1,Ccmykn2,Ccmykn3,Ccmykn4,RAM1,RPM1,RAM2,RPM2,RAM3,RPM3,M,N,dx0,dy0,z1,lambda,aa,bb,dd,ax,ay);

toc

%%
figure,
% histogram(Ccmyk)
ffcmyk=im2uint8(Ccmyk);
fff=imhist(ffcmyk);
bar(fff)
axis([0 300 0 200])

figure,
bar(imhist(im2uint8(f1c)),'c'),hold on
% hold on
bar(imhist(im2uint8(f1m)),'m'),hold on
% hold on
bar(imhist(im2uint8(f1y)),'y'),hold on
% hold on
bar(imhist(im2uint8(f1k)),'k'),hold on
axis([0 256 0 1000])
%%


%%                                                            attacks
% noise=1*randn(size(Ccmyk));
% Ccmyk=Ccmyk+noise*0.1;

Ccmyk(1:128*0.5,1:128*1,:)=0;

% Ccmyk=rescale(load_image('jieping',n1));
% Ccmyk=rgb2gray(Ccmyk);
%%%%

figure,imshow(Ccmyk),title('encrypted image');
imwrite(Ccmyk,'Ccmyk.tiff');




%%% DECRYPTION PROCESS
tic
%%%��һ��%%%

[CCMYK1,CCMYK2,CCMYK3,CCMYK4]=decrypt_FrT_LCT_FrFT(Ccmyk,RAM1,RPM1,RAM2,RPM2,RAM3,RPM3,p33,p22,p11,M,N,dx0,dy0,z1,lambda,aa,bb,dd,ax,ay);

[CCMYKn1,CCMYKn2,CCMYKn3,CCMYKn4]=decrypt_FrT_LCT_FrFT(CCMYK1,RAM1,RPM1,RAM2,RPM2,RAM3,RPM3,pn331,pn221,pn111,M,N,dx0,dy0,z1,lambda,aa,bb,dd,ax,ay);
[CCMYKn5,CCMYKn6,CCMYKn7,CCMYKn8]=decrypt_FrT_LCT_FrFT(CCMYK2,RAM1,RPM1,RAM2,RPM2,RAM3,RPM3,pn332,pn222,pn112,M,N,dx0,dy0,z1,lambda,aa,bb,dd,ax,ay);
[CCMYKn9,CCMYKn10,CCMYKn11,CCMYKn12]=decrypt_FrT_LCT_FrFT(CCMYK3,RAM1,RPM1,RAM2,RPM2,RAM3,RPM3,pn333,pn223,pn113,M,N,dx0,dy0,z1,lambda,aa,bb,dd,ax,ay);
[CCMYKn13,CCMYKn14,CCMYKn15,CCMYKn16]=decrypt_FrT_LCT_FrFT(CCMYK4,RAM1,RPM1,RAM2,RPM2,RAM3,RPM3,pn334,pn224,pn114,M,N,dx0,dy0,z1,lambda,aa,bb,dd,ax,ay);

[F1C,F1M,F1Y,F1K]=decrypt_FrT_LCT_FrFT(CCMYKn1,RAM1,RPM1,RAM2,RPM2,RAM3,RPM3,p331,p221,p111,M,N,dx0,dy0,z1,lambda,aa,bb,dd,ax,ay);
[F2C,F2M,F2Y,F2K]=decrypt_FrT_LCT_FrFT(CCMYKn2,RAM1,RPM1,RAM2,RPM2,RAM3,RPM3,p332,p222,p112,M,N,dx0,dy0,z1,lambda,aa,bb,dd,ax,ay);
[F3C,F3M,F3Y,F3K]=decrypt_FrT_LCT_FrFT(CCMYKn3,RAM1,RPM1,RAM2,RPM2,RAM3,RPM3,p333,p223,p113,M,N,dx0,dy0,z1,lambda,aa,bb,dd,ax,ay);
[F4C,F4M,F4Y,F4K]=decrypt_FrT_LCT_FrFT(CCMYKn4,RAM1,RPM1,RAM2,RPM2,RAM3,RPM3,p334,p224,p114,M,N,dx0,dy0,z1,lambda,aa,bb,dd,ax,ay);
[F5C,F5M,F5Y,F5K]=decrypt_FrT_LCT_FrFT(CCMYKn5,RAM1,RPM1,RAM2,RPM2,RAM3,RPM3,p335,p225,p115,M,N,dx0,dy0,z1,lambda,aa,bb,dd,ax,ay);
[F6C,F6M,F6Y,F6K]=decrypt_FrT_LCT_FrFT(CCMYKn6,RAM1,RPM1,RAM2,RPM2,RAM3,RPM3,p336,p226,p116,M,N,dx0,dy0,z1,lambda,aa,bb,dd,ax,ay);
[F7C,F7M,F7Y,F7K]=decrypt_FrT_LCT_FrFT(CCMYKn7,RAM1,RPM1,RAM2,RPM2,RAM3,RPM3,p337,p227,p117,M,N,dx0,dy0,z1,lambda,aa,bb,dd,ax,ay);
[F8C,F8M,F8Y,F8K]=decrypt_FrT_LCT_FrFT(CCMYKn8,RAM1,RPM1,RAM2,RPM2,RAM3,RPM3,p338,p228,p118,M,N,dx0,dy0,z1,lambda,aa,bb,dd,ax,ay);
[F9C,F9M,F9Y,F9K]=decrypt_FrT_LCT_FrFT(CCMYKn9,RAM1,RPM1,RAM2,RPM2,RAM3,RPM3,p339,p229,p119,M,N,dx0,dy0,z1,lambda,aa,bb,dd,ax,ay);
[F10C,F10M,F10Y,F10K]=decrypt_FrT_LCT_FrFT(CCMYKn10,RAM1,RPM1,RAM2,RPM2,RAM3,RPM3,p3310,p2210,p1110,M,N,dx0,dy0,z1,lambda,aa,bb,dd,ax,ay);
[F11C,F11M,F11Y,F11K]=decrypt_FrT_LCT_FrFT(CCMYKn11,RAM1,RPM1,RAM2,RPM2,RAM3,RPM3,p3311,p2211,p1111,M,N,dx0,dy0,z1,lambda,aa,bb,dd,ax,ay);
[F12C,F12M,F12Y,F12K]=decrypt_FrT_LCT_FrFT(CCMYKn12,RAM1,RPM1,RAM2,RPM2,RAM3,RPM3,p3312,p2212,p1112,M,N,dx0,dy0,z1,lambda,aa,bb,dd,ax,ay);
[F13C,F13M,F13Y,F13K]=decrypt_FrT_LCT_FrFT(CCMYKn13,RAM1,RPM1,RAM2,RPM2,RAM3,RPM3,p3313,p2213,p1113,M,N,dx0,dy0,z1,lambda,aa,bb,dd,ax,ay);
[F14C,F14M,F14Y,F14K]=decrypt_FrT_LCT_FrFT(CCMYKn14,RAM1,RPM1,RAM2,RPM2,RAM3,RPM3,p3314,p2214,p1114,M,N,dx0,dy0,z1,lambda,aa,bb,dd,ax,ay);
[F15C,F15M,F15Y,F15K]=decrypt_FrT_LCT_FrFT(CCMYKn15,RAM1,RPM1,RAM2,RPM2,RAM3,RPM3,p3315,p2215,p1115,M,N,dx0,dy0,z1,lambda,aa,bb,dd,ax,ay);
[F16C,F16M,F16Y,F16K]=decrypt_FrT_LCT_FrFT(CCMYKn16,RAM1,RPM1,RAM2,RPM2,RAM3,RPM3,p3316,p2216,p1116,M,N,dx0,dy0,z1,lambda,aa,bb,dd,ax,ay);

toc

F1CMYK(:,:,1)=F1C;
% figure,imshow(F1C);title('F1C')
F1CMYK(:,:,2)=F1M;
% figure,imshow(F1M);title('F1M')
F1CMYK(:,:,3)=F1Y;
% figure,imshow(F1Y);title('F1Y')
F1CMYK(:,:,4)=F1K;
% figure,imshow(F1K);title('F1K')

% F1CC=cat(3,F1C,zero,zero,zero);
% imwrite(F1CC,'F1CC.tiff');
% F1MM=cat(3,zero,F1M,zero,zero);
% imwrite(F1MM,'F1MM.tiff');
% F1YY=cat(3,zero,zero,F1Y,zero);
% imwrite(F1YY,'F1YY.tiff');
% F1KK=cat(3,zero,zero,zero,F1K);
% imwrite(F1KK,'F1KK.tiff');

F2CMYK(:,:,1)=F2C;
% figure,imshow(F1C);title('F1C')
F2CMYK(:,:,2)=F2M;
% figure,imshow(F1M);title('F1M')
F2CMYK(:,:,3)=F2Y;
% figure,imshow(F1Y);title('F1Y')
F2CMYK(:,:,4)=F2K;
% figure,imshow(F1K);title('F1K')

F3CMYK(:,:,1)=F3C;
% figure,imshow(F1C);title('F1C')
F3CMYK(:,:,2)=F3M;
% figure,imshow(F1M);title('F1M')
F3CMYK(:,:,3)=F3Y;
% figure,imshow(F1Y);title('F1Y')
F3CMYK(:,:,4)=F3K;
% figure,imshow(F1K);title('F1K')

F4CMYK(:,:,1)=F4C;
% figure,imshow(F1C);title('F1C')
F4CMYK(:,:,2)=F4M;
% figure,imshow(F1M);title('F1M')
F4CMYK(:,:,3)=F4Y;
% figure,imshow(F1Y);title('F1Y')
F4CMYK(:,:,4)=F4K;
% figure,imshow(F1K);title('F1K')

F5CMYK(:,:,1)=F5C;
% figure,imshow(F1C);title('F1C')
F5CMYK(:,:,2)=F5M;
% figure,imshow(F1M);title('F1M')
F5CMYK(:,:,3)=F5Y;
% figure,imshow(F1Y);title('F1Y')
F5CMYK(:,:,4)=F5K;
% figure,imshow(F1K);title('F1K')

F6CMYK(:,:,1)=F6C;
% figure,imshow(F1C);title('F1C')
F6CMYK(:,:,2)=F6M;
% figure,imshow(F1M);title('F1M')
F6CMYK(:,:,3)=F6Y;
% figure,imshow(F1Y);title('F1Y')
F6CMYK(:,:,4)=F6K;
% figure,imshow(F1K);title('F1K')

F7CMYK(:,:,1)=F7C;
% figure,imshow(F1C);title('F1C')
F7CMYK(:,:,2)=F7M;
% figure,imshow(F1M);title('F1M')
F7CMYK(:,:,3)=F7Y;
% figure,imshow(F1Y);title('F1Y')
F7CMYK(:,:,4)=F7K;
% figure,imshow(F1K);title('F1K')

F8CMYK(:,:,1)=F8C;
% figure,imshow(F1C);title('F1C')
F8CMYK(:,:,2)=F8M;
% figure,imshow(F1M);title('F1M')
F8CMYK(:,:,3)=F8Y;
% figure,imshow(F1Y);title('F1Y')
F8CMYK(:,:,4)=F8K;
% figure,imshow(F1K);title('F1K')

F9CMYK(:,:,1)=F9C;
% figure,imshow(F1C);title('F1C')
F9CMYK(:,:,2)=F9M;
% figure,imshow(F1M);title('F1M')
F9CMYK(:,:,3)=F9Y;
% figure,imshow(F1Y);title('F1Y')
F9CMYK(:,:,4)=F9K;
% figure,imshow(F1K);title('F1K')

F9CMYK(:,:,1)=F9C;
% figure,imshow(F1C);title('F1C')
F9CMYK(:,:,2)=F9M;
% figure,imshow(F1M);title('F1M')
F9CMYK(:,:,3)=F9Y;
% figure,imshow(F1Y);title('F1Y')
F9CMYK(:,:,4)=F9K;
% figure,imshow(F1K);title('F1K')

F10CMYK(:,:,1)=F10C;
% figure,imshow(F1C);title('F1C')
F10CMYK(:,:,2)=F10M;
% figure,imshow(F1M);title('F1M')
F10CMYK(:,:,3)=F10Y;
% figure,imshow(F1Y);title('F1Y')
F10CMYK(:,:,4)=F10K;
% figure,imshow(F1K);title('F1K')

F11CMYK(:,:,1)=F11C;
% figure,imshow(F1C);title('F1C')
F11CMYK(:,:,2)=F11M;
% figure,imshow(F1M);title('F1M')
F11CMYK(:,:,3)=F11Y;
% figure,imshow(F1Y);title('F1Y')
F11CMYK(:,:,4)=F11K;
% figure,imshow(F1K);title('F1K')

F12CMYK(:,:,1)=F12C;
% figure,imshow(F1C);title('F1C')
F12CMYK(:,:,2)=F12M;
% figure,imshow(F1M);title('F1M')
F12CMYK(:,:,3)=F12Y;
% figure,imshow(F1Y);title('F1Y')
F12CMYK(:,:,4)=F12K;
% figure,imshow(F1K);title('F1K')

F13CMYK(:,:,1)=F13C;
% figure,imshow(F1C);title('F1C')
F13CMYK(:,:,2)=F13M;
% figure,imshow(F1M);title('F1M')
F13CMYK(:,:,3)=F13Y;
% figure,imshow(F1Y);title('F1Y')
F13CMYK(:,:,4)=F13K;
% figure,imshow(F1K);title('F1K')

F14CMYK(:,:,1)=F14C;
% figure,imshow(F1C);title('F1C')
F14CMYK(:,:,2)=F14M;
% figure,imshow(F1M);title('F1M')
F14CMYK(:,:,3)=F14Y;
% figure,imshow(F1Y);title('F1Y')
F14CMYK(:,:,4)=F14K;
% figure,imshow(F1K);title('F1K')

F15CMYK(:,:,1)=F15C;
% figure,imshow(F1C);title('F1C')
F15CMYK(:,:,2)=F15M;
% figure,imshow(F1M);title('F1M')
F15CMYK(:,:,3)=F15Y;
% figure,imshow(F1Y);title('F1Y')
F15CMYK(:,:,4)=F15K;
% figure,imshow(F1K);title('F1K')

F16CMYK(:,:,1)=F16C;
% figure,imshow(F1C);title('F1C')
F16CMYK(:,:,2)=F16M;
% figure,imshow(F1M);title('F1M')
F16CMYK(:,:,3)=F16Y;
% figure,imshow(F1Y);title('F1Y')
F16CMYK(:,:,4)=F16K;
% figure,imshow(F1K);title('F1K')

imwrite(F1CMYK,'images\decrypted_images\F1CMYK.tiff');
imwrite(F2CMYK,'images\decrypted_images\F2CMYK.tiff');
imwrite(F3CMYK,'images\decrypted_images\F3CMYK.tiff');
imwrite(F4CMYK,'images\decrypted_images\F4CMYK.tiff');
imwrite(F5CMYK,'images\decrypted_images\F5CMYK.tiff');
imwrite(F6CMYK,'images\decrypted_images\F6CMYK.tiff');
imwrite(F7CMYK,'images\decrypted_images\F7CMYK.tiff');
imwrite(F8CMYK,'images\decrypted_images\F8CMYK.tiff');
imwrite(F9CMYK,'images\decrypted_images\F9CMYK.tiff');
imwrite(F10CMYK,'images\decrypted_images\F10CMYK.tiff');
imwrite(F11CMYK,'images\decrypted_images\F11CMYK.tiff');
imwrite(F12CMYK,'images\decrypted_images\F12CMYK.tiff');
imwrite(F13CMYK,'images\decrypted_images\F13CMYK.tiff');
imwrite(F14CMYK,'images\decrypted_images\F14CMYK.tiff');
imwrite(F15CMYK,'images\decrypted_images\F15CMYK.tiff');
imwrite(F16CMYK,'images\decrypted_images\F16CMYK.tiff');

F1=cmyk2rgb(F1CMYK );
figure,imshow(F1),title('F1');
% imwrite(drgb2,'image\drgb2.bmp');

F2=cmyk2rgb(F2CMYK );
figure,imshow(F2),title('F2');

F3=cmyk2rgb(F3CMYK );
figure,imshow(F3),title('F3');

F4=cmyk2rgb(F4CMYK );
figure,imshow(F4),title('F4');

F5=cmyk2rgb(F5CMYK );
figure,imshow(F5),title('F5');

F6=cmyk2rgb(F6CMYK );
figure,imshow(F6),title('F6');

F7=cmyk2rgb(F7CMYK );
figure,imshow(F7),title('F7');

F8=cmyk2rgb(F8CMYK );
figure,imshow(F8),title('F8');

F9=cmyk2rgb(F9CMYK );
figure,imshow(F9),title('F9');

F10=cmyk2rgb(F10CMYK );
figure,imshow(F10),title('F10');

F11=cmyk2rgb(F11CMYK );
figure,imshow(F11),title('F11');

F12=cmyk2rgb(F12CMYK );
figure,imshow(F12),title('F12');

F13=cmyk2rgb(F13CMYK );
figure,imshow(F13),title('F13');

F14=cmyk2rgb(F14CMYK );
figure,imshow(F14),title('F14');

F15=cmyk2rgb(F15CMYK );
figure,imshow(F15),title('F15');

F16=cmyk2rgb(F16CMYK );
figure,imshow(F16),title('F16');

% %%%Quantive evaluation%%% 
% %%%������ͼ֮��ľ������ͷ�ֵ�����
% % MSE1=norm(f1(:)-F1(:))/norm(f1(:))
% % PSNR1=20*log10(255/sqrt(MSE1))
% % 
% % MSE1=norm(f1(:)-F1(:))/norm(f1(:))
% % PSNR1=20*log10(255/sqrt(MSE1))


%%%������ͼ��֮������ϵ��

imgA11=f1cmyk(:)-mean2(f1cmyk(:));
imgB11=F1CMYK(:)-mean2(F1CMYK(:));
CC1cmyk=sum(sum(imgA11.*imgB11))./(sqrt(sum(sum(imgA11.^2))).*sqrt(sum(sum(imgB11.^2))))

imgA22=f2cmyk(:)-mean2(f2cmyk(:));
imgB22=F2CMYK(:)-mean2(F2CMYK(:));
CC2cmyk=sum(sum(imgA22.*imgB22))./(sqrt(sum(sum(imgA22.^2))).*sqrt(sum(sum(imgB22.^2))))

imgA33=f3cmyk(:)-mean2(f3cmyk(:));
imgB33=F3CMYK(:)-mean2(F3CMYK(:));
CC3cmyk=sum(sum(imgA33.*imgB33))./(sqrt(sum(sum(imgA33.^2))).*sqrt(sum(sum(imgB33.^2))))

imgA44=f4cmyk(:)-mean2(f4cmyk(:));
imgB44=F4CMYK(:)-mean2(F4CMYK(:));
CC4cmyk=sum(sum(imgA44.*imgB44))./(sqrt(sum(sum(imgA44.^2))).*sqrt(sum(sum(imgB44.^2))))

imgA55=f5cmyk(:)-mean2(f5cmyk(:));
imgB55=F5CMYK(:)-mean2(F5CMYK(:));
CC5cmyk=sum(sum(imgA55.*imgB55))./(sqrt(sum(sum(imgA55.^2))).*sqrt(sum(sum(imgB55.^2))))

imgA66=f6cmyk(:)-mean2(f6cmyk(:));
imgB66=F6CMYK(:)-mean2(F6CMYK(:));
CC6cmyk=sum(sum(imgA66.*imgB66))./(sqrt(sum(sum(imgA66.^2))).*sqrt(sum(sum(imgB66.^2))))

imgA77=f7cmyk(:)-mean2(f7cmyk(:));
imgB77=F7CMYK(:)-mean2(F7CMYK(:));
CC7cmyk=sum(sum(imgA77.*imgB77))./(sqrt(sum(sum(imgA77.^2))).*sqrt(sum(sum(imgB77.^2))))

imgA88=f8cmyk(:)-mean2(f8cmyk(:));
imgB88=F8CMYK(:)-mean2(F8CMYK(:));
CC8cmyk=sum(sum(imgA88.*imgB88))./(sqrt(sum(sum(imgA88.^2))).*sqrt(sum(sum(imgB88.^2))))

imgA99=f9cmyk(:)-mean2(f9cmyk(:));
imgB99=F9CMYK(:)-mean2(F9CMYK(:));
CC9cmyk=sum(sum(imgA99.*imgB99))./(sqrt(sum(sum(imgA99.^2))).*sqrt(sum(sum(imgB99.^2))))

imgA110=f10cmyk(:)-mean2(f10cmyk(:));
imgB110=F10CMYK(:)-mean2(F10CMYK(:));
CC10cmyk=sum(sum(imgA110.*imgB110))./(sqrt(sum(sum(imgA110.^2))).*sqrt(sum(sum(imgB110.^2))))

imgA111=f11cmyk(:)-mean2(f11cmyk(:));
imgB111=F11CMYK(:)-mean2(F11CMYK(:));
CC11cmyk=sum(sum(imgA111.*imgB111))./(sqrt(sum(sum(imgA111.^2))).*sqrt(sum(sum(imgB111.^2))))

imgA112=f12cmyk(:)-mean2(f12cmyk(:));
imgB112=F12CMYK(:)-mean2(F12CMYK(:));
CC12cmyk=sum(sum(imgA112.*imgB112))./(sqrt(sum(sum(imgA112.^2))).*sqrt(sum(sum(imgB112.^2))))

imgA113=f13cmyk(:)-mean2(f13cmyk(:));
imgB113=F13CMYK(:)-mean2(F13CMYK(:));
CC13cmyk=sum(sum(imgA113.*imgB113))./(sqrt(sum(sum(imgA113.^2))).*sqrt(sum(sum(imgB113.^2))))

imgA114=f14cmyk(:)-mean2(f14cmyk(:));
imgB114=F14CMYK(:)-mean2(F14CMYK(:));
CC14cmyk=sum(sum(imgA114.*imgB114))./(sqrt(sum(sum(imgA114.^2))).*sqrt(sum(sum(imgB114.^2))))

imgA115=f15cmyk(:)-mean2(f15cmyk(:));
imgB115=F15CMYK(:)-mean2(F15CMYK(:));
CC15cmyk=sum(sum(imgA115.*imgB115))./(sqrt(sum(sum(imgA115.^2))).*sqrt(sum(sum(imgB115.^2))))

imgA116=f16cmyk(:)-mean2(f16cmyk(:));
imgB116=F16CMYK(:)-mean2(F16CMYK(:));
CC16cmyk=sum(sum(imgA116.*imgB116))./(sqrt(sum(sum(imgA116.^2))).*sqrt(sum(sum(imgB116.^2))))

imgA =f16c(:)-mean2(f16c(:));
imgB =Ccmyk(:)-mean2(Ccmyk(:));
CC=sum(sum(imgA .*imgB ))./(sqrt(sum(sum(imgA .^2))).*sqrt(sum(sum(imgB .^2))))

 

