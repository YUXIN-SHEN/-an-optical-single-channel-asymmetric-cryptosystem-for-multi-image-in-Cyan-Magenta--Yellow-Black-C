close all
clear all
clc
path(path,'toolbox');

n1=256;
M=n1;N=n1;
z1=0.9;%the distance of the FrT
lambda=0.6328*1e-7;%the wavelength of the FrT

hx=2.1095*1e-2;hy=2.1095*1e-2;
dhx=hx/M;dhy=hy/N;
dx0=lambda*z1/(M*dhx);
dy0=lambda*z1/(N*dhy);

%%
%the transform parameters of the LCT
aa=2;
bb=1;
dd=7;
%%

%%
%the fractional orders of the FrFT
ax=0.9;
ay=1.1;
%%
% f1cmyk=rescale(load_image('4a',n1));%Peppers

f1cmyk=rescale(load_image('4b',n1));% the color QR code of  ��Peppers��

% f1=cmyk2rgb(f1cmyk);
% figure,imshow(f1);title('f1')

f1c=f1cmyk(:,:,1);
f1m=f1cmyk(:,:,2);
f1y=f1cmyk(:,:,3);
f1k=f1cmyk(:,:,4);
% imwrite(f1c,'images\encrypted_images\f1c.bmp');
% imwrite(f1m,'images\encrypted_images\f1m.bmp');
% imwrite(f1y,'images\encrypted_images\f1y.bmp');
% imwrite(f1k,'images\encrypted_images\f1k.bmp');

figure,
bar(imhist(im2uint8(f1c)),'c'),hold on
% hold on
bar(imhist(im2uint8(f1m)),'m'),hold on
% hold on
bar(imhist(im2uint8(f1y)),'y'),hold on
% hold on
bar(imhist(im2uint8(f1k)),'k'),hold on
axis([0 300 0 1000])
grid on

RPM1=exp(1i*2*pi*rand(M,N));
RPM2=exp(1i*2*pi*rand(M,N));
RPM3=exp(1i*2*pi*rand(M,N));
RAM1=ones(M,N);
RAM2=ones(M,N);
RAM3=ones(M,N);
% RAM1=1;
% RAM2=1;
% RAM3=1;
%%% ENCRYPTION PROCESS
tic
[Ccmyk1,p331,p221,p111]=encrypt_FrT_LCT_FrFT(f1c,f1m,f1y,f1k,RAM1,RPM1,RAM2,RPM2,RAM3,RPM3,M,N,dx0,dy0,z1,lambda,aa,bb,dd,ax,ay);
Ccmyk=Ccmyk1;
toc
imwrite(Ccmyk,'images\encrypted_images\Ccmyk.tiff');
imwrite(p331,'images\mainkeys_P\p331.tiff');
imwrite(p221,'images\mainkeys_P\p221.tiff');
imwrite(p111,'images\mainkeys_P\p111.tiff');
%%
Caa1=Correlation_of_adjacent_pixels(Ccmyk,1,3000)
Caa2=Correlation_of_adjacent_pixels(Ccmyk,2,3000)
Caa3=Correlation_of_adjacent_pixels(Ccmyk,3,3000)

%%
figure,
bar(imhist(im2uint8(Ccmyk)));
axis([0 300 0 1000])
grid on

%%             attacks
% noise=1*randn(size(Ccmyk));
% Ccmyk=Ccmyk+noise*0.1;

 kk1=0.5;
 kk2=0.25;
Ccmyk(1:n1*kk1,1:n1*kk2)=0;
cutkk=kk1*kk2;
%%

figure,imshow(Ccmyk),title('encrypted image');

%%% DECRYPTION PROCESS
tic
% p331=p221;
% RAM3=p221;
% RPM3=p221;
% z1=0.2;ax=20;
% lambda=0.2;ax=20;
% aa=200;ax=20;
% bb=200;ax=20;
% dd=200;ax=20;
% ax=20;
% ay=30;

[F1C,F1M,F1Y,F1K]=decrypt_FrT_LCT_FrFT(Ccmyk,RAM1,RPM1,RAM2,RPM2,RAM3,RPM3,p331,p221,p111,M,N,dx0,dy0,z1,lambda,aa,bb,dd,ax,ay);

toc

F1CMYK(:,:,1)=F1C;
F1CMYK(:,:,2)=F1M;
F1CMYK(:,:,3)=F1Y;
F1CMYK(:,:,4)=F1K;

imwrite(F1CMYK,'images\de4imgs\F1CMYK.tiff');

F1=cmyk2rgb(F1CMYK );
figure,imshow(F1),title('F1');

% %%%Quantive evaluation%%% 
MSE1=norm(f1cmyk(:)-F1CMYK(:))/norm(f1cmyk(:))
PSNR1=20*log10(255/sqrt(MSE1))
[anmse, nmse] = compute_NMSE(f1cmyk,F1CMYK)

%%%

imgA11=f1cmyk(:)-mean2(f1cmyk(:));
imgB11=F1CMYK(:)-mean2(F1CMYK(:));
CC1cmyk=sum(sum(imgA11.*imgB11))./(sqrt(sum(sum(imgA11.^2))).*sqrt(sum(sum(imgB11.^2))))

imgAc=f1c(:)-mean2(f1c(:));
imgBc=F1C(:)-mean2(F1C(:));
CC1c=sum(sum(imgAc.*imgBc))./(sqrt(sum(sum(imgAc.^2))).*sqrt(sum(sum(imgBc.^2))))

imgAm=f1m(:)-mean2(f1m(:));
imgBm=F1M(:)-mean2(F1M(:));
CC1m=sum(sum(imgAm.*imgBm))./(sqrt(sum(sum(imgAm.^2))).*sqrt(sum(sum(imgBm.^2))))

imgAy=f1y(:)-mean2(f1y(:));
imgBy=F1Y(:)-mean2(F1Y(:));
CC1y=sum(sum(imgAy.*imgBy))./(sqrt(sum(sum(imgAy.^2))).*sqrt(sum(sum(imgBy.^2))))

imgAk=f1k(:)-mean2(f1k(:));
imgBk=F1K(:)-mean2(F1K(:));
CC1k=sum(sum(imgAk.*imgBk))./(sqrt(sum(sum(imgAk.^2))).*sqrt(sum(sum(imgBk.^2))))

imgAcc=Ccmyk(:)-mean2(Ccmyk(:));
imgBcc=F1K(:)-mean2(F1K(:));
CCccc=sum(sum(imgAcc.*imgBcc))./(sqrt(sum(sum(imgAcc.^2))).*sqrt(sum(sum(imgBcc.^2))))
