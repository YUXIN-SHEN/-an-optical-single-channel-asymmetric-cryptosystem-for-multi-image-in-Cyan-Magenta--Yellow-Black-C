close all
clear all
clc
path(path,'toolbox');

n1=256;
M=n1;N=n1;
z1=0.9;%the distance of the FrT
lambda=0.6328*1e-7;%%the wavelength of the FrT

hx=2.1095*1e-2;hy=2.1095*1e-2;
dhx=hx/M;dhy=hy/N;
dx0=lambda*z1/(M*dhx);
dy0=lambda*z1/(N*dhy);

%%
%LCT����
aa=2;
bb=1;
dd=7;
%%

%%
%FrFT����
ax=1.25;
ay=1.1;
%%% Four plain images ��Peppers��, ��Fruits��, ��Splash�� and ��Baboon��; 
% f1cmyk=rescale(load_image('5a1',n1));
% % % f2cmyk=zeros(size(f1cmyk));
% f2cmyk=rescale(load_image('5a2',n1));
% f3cmyk=rescale(load_image('5a3',n1));
% f4cmyk=rescale(load_image('5a4',n1));

%%%four color QR codes of ��Peppers��, ��Fruits��, ��Splash�� and ��Baboon��, respectively
f1cmyk=rescale(load_image('5b1',n1));
% f2cmyk=zeros(size(f1cmyk));
f2cmyk=rescale(load_image('5b2',n1));
f3cmyk=rescale(load_image('5b3',n1));
f4cmyk=rescale(load_image('5b4',n1));

% f1cmyk=rescale(load_image('brain 5',n1));
% % % f2cmyk=zeros(size(f1cmyk));
% f2cmyk=rescale(load_image('brain 6',n1));
% f3cmyk=rescale(load_image('brain 7',n1));
% f4cmyk=rescale(load_image('brain 8',n1));

% f1=cmyk2rgb(f1cmyk);
% figure,imshow(f1);title('f1')
% 
% f2=cmyk2rgb(f2cmyk);
% figure,imshow(f2);title('f2')
% 
% f3=cmyk2rgb(f3cmyk);
% figure,imshow(f3);title('f3')
% 
% f4=cmyk2rgb(f4cmyk);
% figure,imshow(f4);title('f4')
 
f1c=f1cmyk(:,:,1);
f1m=f1cmyk(:,:,2);
f1y=f1cmyk(:,:,3);
f1k=f1cmyk(:,:,4);

f2c=f2cmyk(:,:,1);
f2m=f2cmyk(:,:,2);
f2y=f2cmyk(:,:,3);
f2k=f2cmyk(:,:,4);

f3c=f3cmyk(:,:,1);
f3m=f3cmyk(:,:,2);
f3y=f3cmyk(:,:,3);
f3k=f3cmyk(:,:,4);

f4c=f4cmyk(:,:,1);
f4m=f4cmyk(:,:,2);
f4y=f4cmyk(:,:,3);
f4k=f4cmyk(:,:,4);

RPM1=exp(1i*2*pi*rand(M,N));
RPM2=exp(1i*2*pi*rand(M,N));
RPM3=exp(1i*2*pi*rand(M,N));
RAM1=ones(M,N);
RAM2=ones(M,N);
RAM3=ones(M,N);
% RAM1=1;
% RAM2=1;
% RAM3=1;

%% 
figure,
bar(imhist(im2uint8(f1c)),'c'),hold on
bar(imhist(im2uint8(f1m)),'m'),hold on
bar(imhist(im2uint8(f1y)),'y'),hold on
bar(imhist(im2uint8(f1k)),'k'),hold on
axis([0 256 0 1500])

figure,
bar(imhist(im2uint8(f2c)),'c'),hold on
bar(imhist(im2uint8(f2m)),'m'),hold on
bar(imhist(im2uint8(f2y)),'y'),hold on
bar(imhist(im2uint8(f2k)),'k'),hold on
axis([0 256 0 1500])

figure,
bar(imhist(im2uint8(f3c)),'c'),hold on
bar(imhist(im2uint8(f3m)),'m'),hold on
bar(imhist(im2uint8(f3y)),'y'),hold on
bar(imhist(im2uint8(f3k)),'k'),hold on
axis([0 256 0 1500])

figure,
bar(imhist(im2uint8(f4c)),'c'),hold on
bar(imhist(im2uint8(f4m)),'m'),hold on
bar(imhist(im2uint8(f4y)),'y'),hold on
bar(imhist(im2uint8(f4k)),'k'),hold on
axis([0 256 0 1500])
%%
%%% ENCRYPTION PROCESS
tic

[Ccmyk1,p331,p221,p111]=encrypt_FrT_LCT_FrFT(f1c,f1m,f1y,f1k,RAM1,RPM1,RAM2,RPM2,RAM3,RPM3,M,N,dx0,dy0,z1,lambda,aa,bb,dd,ax,ay);
[Ccmyk2,p332,p222,p112]=encrypt_FrT_LCT_FrFT(f2c,f2m,f2y,f2k,RAM1,RPM1,RAM2,RPM2,RAM3,RPM3,M,N,dx0,dy0,z1,lambda,aa,bb,dd,ax,ay);
[Ccmyk3,p333,p223,p113]=encrypt_FrT_LCT_FrFT(f3c,f3m,f3y,f3k,RAM1,RPM1,RAM2,RPM2,RAM3,RPM3,M,N,dx0,dy0,z1,lambda,aa,bb,dd,ax,ay);
[Ccmyk4,p334,p224,p114]=encrypt_FrT_LCT_FrFT(f4c,f4m,f4y,f4k,RAM1,RPM1,RAM2,RPM2,RAM3,RPM3,M,N,dx0,dy0,z1,lambda,aa,bb,dd,ax,ay);

[Ccmyk,p33,p22,p11]=encrypt_FrT_LCT_FrFT(Ccmyk1,Ccmyk2,Ccmyk3,1.1*Ccmyk4,RAM1,RPM1,RAM2,RPM2,RAM3,RPM3,M,N,dx0,dy0,z1,lambda,aa,bb,dd,ax,ay);
toc

imwrite(Ccmyk,'images\encrypted_images\Ccmyk.tiff');
imwrite(p331,'images\mainkeys_P\p331.tiff');
imwrite(p221,'images\mainkeys_P\p221.tiff');
imwrite(p111,'images\mainkeys_P\p111.tiff');
imwrite(p332,'images\mainkeys_P\p332.tiff');
imwrite(p222,'images\mainkeys_P\p222.tiff');
imwrite(p112,'images\mainkeys_P\p112.tiff');
imwrite(p333,'images\mainkeys_P\p333.tiff');
imwrite(p223,'images\mainkeys_P\p223.tiff');
imwrite(p113,'images\mainkeys_P\p113.tiff');
imwrite(p334,'images\mainkeys_P\p334.tiff');
imwrite(p224,'images\mainkeys_P\p224.tiff');
imwrite(p114,'images\mainkeys_P\p114.tiff');
imwrite(p33,'images\mainkeys_P\p33.tiff');
imwrite(p22,'images\mainkeys_P\p22.tiff');
imwrite(p11,'images\mainkeys_P\p11.tiff');
%%
Cacmyk1=Correlation_of_adjacent_pixels(Ccmyk,1,3000)
Cacmyk2=Correlation_of_adjacent_pixels(Ccmyk,2,3000)
Cacmyk3=Correlation_of_adjacent_pixels(Ccmyk,3,3000)

Caf11=Correlation_of_adjacent_pixels(f1cmyk,1,3000)
Caf12=Correlation_of_adjacent_pixels(f1cmyk,2,3000)
Caf13=Correlation_of_adjacent_pixels(f1cmyk,3,3000)

Caf21=Correlation_of_adjacent_pixels(f2cmyk,1,3000)
Caf22=Correlation_of_adjacent_pixels(f2cmyk,2,3000)
Caf23=Correlation_of_adjacent_pixels(f2cmyk,3,3000)

Caf31=Correlation_of_adjacent_pixels(f3cmyk,1,3000)
Caf32=Correlation_of_adjacent_pixels(f3cmyk,2,3000)
Caf33=Correlation_of_adjacent_pixels(f3cmyk,3,3000)

Caf41=Correlation_of_adjacent_pixels(f4cmyk,1,3000)
Caf42=Correlation_of_adjacent_pixels(f4cmyk,2,3000)
Caf43=Correlation_of_adjacent_pixels(f4cmyk,3,3000)
%%
figure,
ffcmyk=im2uint8(Ccmyk);
fff=imhist(ffcmyk);
bar(fff)
axis([0 300 0 850])


%%             attacks
% noise=1*randn(size(Ccmyk));
% Ccmyk=Ccmyk+noise*0.1;

 kk1=0.5;
 kk2=0.25;
Ccmyk(1:n1*kk1,1:n1*kk2)=0;
cutkk=kk1*kk2;
%%

figure,imshow(Ccmyk),title('encrypted image');
imwrite(Ccmyk,'images\encrypted_images\Ccmykatk.tiff');


%%% DECRYPTION PROCESS
tic
% % P3
% p33=p22;
% %P3_1          
% p331=p22;
% %P3_2
% p332=p22;
% %P3_3
% p333=p22;
% %P3_4
% p334=p22;

% RAM3=p221;
% RPM3=p221;
% z1=0.2;ax=20;
% lambda=0.2;ax=20;
% aa=200;ax=20;
% bb=200;ax=20;
% dd=200;ax=20;
% ax=20;
% ay=30;

[CCMYK1,CCMYK2,CCMYK3,CCMYK4]=decrypt_FrT_LCT_FrFT(Ccmyk,RAM1,RPM1,RAM2,RPM2,RAM3,RPM3,p33,p22,p11,M,N,dx0,dy0,z1,lambda,aa,bb,dd,ax,ay);

[F1C,F1M,F1Y,F1K]=decrypt_FrT_LCT_FrFT(CCMYK1,RAM1,RPM1,RAM2,RPM2,RAM3,RPM3,p331,p221,p111,M,N,dx0,dy0,z1,lambda,aa,bb,dd,ax,ay);
[F2C,F2M,F2Y,F2K]=decrypt_FrT_LCT_FrFT(CCMYK2,RAM1,RPM1,RAM2,RPM2,RAM3,RPM3,p332,p222,p112,M,N,dx0,dy0,z1,lambda,aa,bb,dd,ax,ay);
[F3C,F3M,F3Y,F3K]=decrypt_FrT_LCT_FrFT(CCMYK3,RAM1,RPM1,RAM2,RPM2,RAM3,RPM3,p333,p223,p113,M,N,dx0,dy0,z1,lambda,aa,bb,dd,ax,ay);
[F4C,F4M,F4Y,F4K]=decrypt_FrT_LCT_FrFT(CCMYK4,RAM1,RPM1,RAM2,RPM2,RAM3,RPM3,p334,p224,p114,M,N,dx0,dy0,z1,lambda,aa,bb,dd,ax,ay);

toc

F1CMYK(:,:,1)=F1C;
F1CMYK(:,:,2)=F1M;
F1CMYK(:,:,3)=F1Y;
F1CMYK(:,:,4)=F1K;

F2CMYK(:,:,1)=F2C;
F2CMYK(:,:,2)=F2M;
F2CMYK(:,:,3)=F2Y;
F2CMYK(:,:,4)=F2K;

F3CMYK(:,:,1)=F3C;
F3CMYK(:,:,2)=F3M;
F3CMYK(:,:,3)=F3Y;
F3CMYK(:,:,4)=F3K;

F4CMYK(:,:,1)=F4C;
F4CMYK(:,:,2)=F4M;
F4CMYK(:,:,3)=F4Y;
F4CMYK(:,:,4)=F4K;

imwrite(F1CMYK,'images\de4imgs\F1CMYK.tiff');
imwrite(F2CMYK,'images\de4imgs\F2CMYK.tiff');
imwrite(F3CMYK,'images\de4imgs\F3CMYK.tiff');
imwrite(F4CMYK,'images\de4imgs\F4CMYK.tiff');

F1=cmyk2rgb(F1CMYK );
figure,imshow(F1),title('F1');

F2=cmyk2rgb(F2CMYK );
figure,imshow(F2),title('F2');

F3=cmyk2rgb(F3CMYK );
figure,imshow(F3),title('F3');

F4=cmyk2rgb(F4CMYK );
figure,imshow(F4),title('F4');

%% Quantive evaluation

MSE1=norm(f1cmyk(:)-F1CMYK(:))/norm(f1cmyk(:))
PSNR1=20*log10(255/sqrt(MSE1))
MSE2=norm(f2cmyk(:)-F2CMYK(:))/norm(f2cmyk(:))
PSNR2=20*log10(255/sqrt(MSE2))
MSE3=norm(f3cmyk(:)-F3CMYK(:))/norm(f3cmyk(:))
PSNR3=20*log10(255/sqrt(MSE3))
MSE4=norm(f4cmyk(:)-F4CMYK(:))/norm(f4cmyk(:))
PSNR4=20*log10(255/sqrt(MSE4))

imgA11=f1cmyk(:)-mean2(f1cmyk(:));
imgB11=F1CMYK(:)-mean2(F1CMYK(:));
CC1cmyk=sum(sum(imgA11.*imgB11))./(sqrt(sum(sum(imgA11.^2))).*sqrt(sum(sum(imgB11.^2))))

imgA22=f2cmyk(:)-mean2(f2cmyk(:));
imgB22=F2CMYK(:)-mean2(F2CMYK(:));
CC2cmyk=sum(sum(imgA22.*imgB22))./(sqrt(sum(sum(imgA22.^2))).*sqrt(sum(sum(imgB22.^2))))

imgA33=f3cmyk(:)-mean2(f3cmyk(:));
imgB33=F3CMYK(:)-mean2(F3CMYK(:));
CC3cmyk=sum(sum(imgA33.*imgB33))./(sqrt(sum(sum(imgA33.^2))).*sqrt(sum(sum(imgB33.^2))))

imgA44=f4cmyk(:)-mean2(f4cmyk(:));
imgB44=F4CMYK(:)-mean2(F4CMYK(:));
CC4cmyk=sum(sum(imgA44.*imgB44))./(sqrt(sum(sum(imgA44.^2))).*sqrt(sum(sum(imgB44.^2))))

imgAcc=Ccmyk(:)-mean2(Ccmyk(:));
imgBcc=F1K(:)-mean2(F1K(:));
CCccc=sum(sum(imgAcc.*imgBcc))./(sqrt(sum(sum(imgAcc.^2))).*sqrt(sum(sum(imgBcc.^2))))

CCvalues=[CC1cmyk CC2cmyk CC3cmyk CC4cmyk];
meanCC=mean(CCvalues);
anss=[CC1cmyk CC2cmyk CC3cmyk CC4cmyk meanCC]
