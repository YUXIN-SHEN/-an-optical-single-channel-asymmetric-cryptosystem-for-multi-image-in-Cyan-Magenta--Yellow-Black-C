function IC=arnold(IO,a,b,n) 
[h w]=size(IO);
imgn=zeros(h,w);
N=h;
for i=1:n
    for y=1:h
        for x=1:w           
            xx=mod((x-1)+b*(y-1),N)+1;
            yy=mod(a*(x-1)+(a*b+1)*(y-1),N)+1;        
            imgn(yy,xx)=IO(y,x);                
        end
    end
    IO=imgn;
end
IC=imgn;

