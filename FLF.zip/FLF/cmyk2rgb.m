
function im = cmyk2rgb(cmyk)

    cform = makecform('cmyk2srgb');
    im = applycform(cmyk, cform);
    
end