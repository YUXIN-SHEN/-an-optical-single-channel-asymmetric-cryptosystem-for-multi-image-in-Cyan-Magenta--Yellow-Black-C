% COMPUTE_NMSE : compute NMSEs

function [anmse, nmse] = compute_NMSE(ref_im,recon_im)
ref_im(ref_im>500) = 0;
    ref_im(ref_im<0) = 0;
    recon_im(ref_im>500) = 0;
     recon_im(ref_im<0) = 0;
     ref_im(isnan(ref_im))=0;
     recon_im(isnan(recon_im))=0;
     ref_im(abs(ref_im-recon_im)>50) = 0;
     recon_im(abs(ref_im-recon_im)>50) = 0;
%nmse = squeeze(sum(sum((ref_im-recon_im).^2,1),2)./sum(sum(ref_im.^2,1),2));
   nmse = sqrt(sum(abs(abs(ref_im(:))-abs(recon_im(:))).^2)./sum(ref_im(:).^2));
anmse = mean(nmse);

