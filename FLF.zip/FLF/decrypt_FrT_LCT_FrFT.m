function [dc,dm,dy,dk]=decrypt_FrT_LCT_FrFT(Ccmyk,RAM1,RPM1,RAM2,RPM2,RAM3,RPM3,p33,p22,p11,M,N,dx0,dy0,z1,lambda,aa,bb,dd,ax,ay);
% p33=p22;%��Կ����ʱ

dcmyk=frftc2d(Ccmyk.*p33,-ax,-ay);
dcmy=real(dcmyk.*conj(RPM3)./RAM3);
dk=imag(dcmyk.*conj(RPM3)./RAM3);
dcym=lct(dcmy.*p22,-dd,-bb,-aa);
dcm=real(dcym.*conj(RPM2)./RAM2);
dy=imag(dcym.*conj(RPM2)./RAM2);
dmc=fresnel(dcm.*p11,M,N,dx0,dy0,-z1,lambda);
dc=real(dmc.*conj(RPM1)./RAM1);
dm=imag(dmc.*conj(RPM1)./RAM1);