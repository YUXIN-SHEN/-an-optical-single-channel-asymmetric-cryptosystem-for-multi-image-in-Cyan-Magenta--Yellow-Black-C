function [Ccmyk,p33,p22,p11]=encrypt_FrT_LCT_FrFT(fc,fm,fy,fk,RAM1,RPM1,RAM2,RPM2,RAM3,RPM3,M,N,dx0,dy0,z1,lambda,aa,bb,dd,ax,ay);
% fc=(1.5).*fc;
% fm=(1.5).*fm;
% fy=(1.5).*fy;
% fk=(1.2).*fk;
fcm=fc+1i*fm;
fcmm=fcm.*RPM1.*RAM1;
p11=exp(1i*angle(fresnel(fcmm,M,N,dx0,dy0,z1,lambda)));
Ccm=abs(fresnel(fcmm,M,N,dx0,dy0,z1,lambda));
fcmy=Ccm+1i*fy;
fcmym=fcmy.*RPM2.*RAM2;
p22=exp(1i*angle( lct(fcmym,aa,bb,dd) ));
Ccmy=abs( lct(fcmym,aa,bb,dd) );
fcmyk=Ccmy+1i*fk;
fcmykm=fcmyk.*RPM3.*RAM3;
p33=exp(1i*angle( frftc2d(fcmykm,ax,ay)) );
Ccmyk=abs( frftc2d(fcmykm,ax,ay) );

% lct(f,aa,bb,dd)
%frftc2d(f,ax,ay)