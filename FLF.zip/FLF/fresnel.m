%���������־������� 
function [f1,dx1,dy1,x1,y1] = fresnel(f0,M,N,dx0,dy0,z,lambda) 
%lamda=0.6328
%k=2*pi/lambda; 
du=1./(M*dx0); 
dv=1./(N*dy0); 
u=ones(N,1)*[0:M/2-1 -M/2:-1]*du;                      %Note order of points for FFT 
v=[0:N/2-1 -N/2:-1]'*ones(1,M)*dv; 
H=exp(-1i*pi*lambda*z*(u.^2+v.^2));         %Fourier transform of kernel 
f1=ifft2(fft2(f0).*H);                     %Convolution
dx1=dx0;dy1=dy0; 
x1=ones(N,1)*(-M/2:M/2-1)*dx1;                         %Baseline for output 
y1=(-N/2:N/2-1)'*ones(1,M)*dy1;