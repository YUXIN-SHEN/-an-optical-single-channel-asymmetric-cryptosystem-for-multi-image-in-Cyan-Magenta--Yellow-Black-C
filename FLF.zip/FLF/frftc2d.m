function ff=frftc2d(f,ax,ay);
% by conv
ax = ax*pi/2; % ת��Ϊ�任��
ay = ay*pi/2; % ת��Ϊ�任��
warning off;
[M,N] = size(f);
[x,y] = meshgrid(([0:N-1]-N/2)/sqrt(N),([0:M-1]-M/2)/sqrt(M));
Ba = exp(i*pi*[x.^2*csc(ax)+y.^2*csc(ay)]);
Bpa = exp(-i*pi*[x.^2*tan(ax/2)+y.^2*tan(ay/2)]);
fa = f.*Bpa;
C1 = fftshift(fft2(fftshift(fa)));
C2 = exp(-i*pi*[x.^2*sin(ax)+y.^2*sin(ay)]);
CC = fftshift(ifft2(fftshift(C1.*C2)));
ff = Bpa.*CC;
ff = ff*(1-i*cot(ax));