close all
clear all
clc
img=imread('Ccmyk.tiff'); 
%  p=rgb2gray(img); 
 h=imhist(img); 
 h1=h(1:2:256); 
 h2=1:2:256; 
 stem(h2,h1,'b-'); 
 figure,imhist(img);