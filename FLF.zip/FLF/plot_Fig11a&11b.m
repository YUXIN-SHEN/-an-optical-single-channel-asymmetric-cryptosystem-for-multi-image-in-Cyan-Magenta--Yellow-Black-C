clc;clear all; close all
%% Without QR code-based
%% cut
x1=[0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9];
y1=[1 0.9849 0.9382 0.8755 0.8020 0.7200 0.6343 0.5396 0.4346 0.3030];
figure,

plot(x1,y1,'MarkerEdgeColor',[1 0 0],'MarkerSize',8,'Marker','*',...
    'LineWidth',2,...
    'Color',[1 0 0])
%% noise attack
% x1=[0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0];
% y1=[1 0.9966 0.9868 0.9713 0.9512 0.9271 0.9025 0.8752 0.8489 0.8208 0.7946];
% figure,plot(x1,y1,'MarkerEdgeColor',[1 0 0],'MarkerSize',8,'Marker','*',...
%     'LineWidth',2,...
%     'Color',[1 0 0])


%% QR code-based
%% cut
hold on 
x2=[0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9];
y2=[1 0.9897 0.9583 0.9104 0.8444 0.7704 0.6871 0.5874 0.4777 0.3329];
plot(x2,y2,'MarkerEdgeColor',[0 0 1],'MarkerSize',8,'Marker','*',...
    'LineWidth',2,...
    'Color',[0 0 1])
box on
legend('Without QR','With QR')
axis([0 0.9 0 1])

%% noise
% hold on
% x2=[0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0];
% y2=[1 0.9985 0.9941 0.9870 0.9772 0.9649 0.9509 0.9355 0.9180 0.9002 0.8808];
% plot(x2,y2,'MarkerEdgeColor',[0 0 1],'MarkerSize',8,'Marker','*',...
%     'LineWidth',2,...
%     'Color',[0 0 1])
% box on
% legend('Without QR','With QR')

